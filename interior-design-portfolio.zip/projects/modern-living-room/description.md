# Modern Living Room Design

**Project Type:** Residential  
**Tools Used:** SketchUp 2021, V-Ray 6.5, Photoshop CC  
**Description:**  
A modern living room design featuring neutral tones, ambient lighting, and ergonomic furniture arrangement. The design emphasizes spaciousness and clean aesthetics with a Scandinavian influence.

**Features:**
- 3D model in SketchUp
- High-resolution render in V-Ray
- Post-processed in Photoshop
